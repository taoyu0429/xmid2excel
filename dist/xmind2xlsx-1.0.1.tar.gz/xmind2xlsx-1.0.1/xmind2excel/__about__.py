__title__ = 'xmind2xlsx'
__description__ = 'Xmind2Xlsx基于Python实现，提供了一个高效测试用例设计的解决方案！'
__keywords__ = 'Xmind2Xlsx, testcase, test, testing, xmind, 思维导图, XMind思维导图',
__author__ = 'tao'
__author_email__ = '1126931536@qq.com'
__url__ = 'https://github.com/zhuifengshen/xmind2testcase'
__version__ = '1.0.1'
__license__ = 'MIT'

